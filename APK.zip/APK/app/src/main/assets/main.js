function VideoDurationNavigator(id,vid,aid){
let video = document.getElementById(vid)
let nav = document.getElementById(id)
nav.ontouchmove = function(e){
  var v =e.touches[0].clientX-(this.offsetLeft*2)
  let root = document.querySelector(":root");
  if (v > -5) {
    var duration = v*(video.duration/this.offsetWidth);
    root.style.setProperty("--v",v+"px");
    video.currentTime =duration;
    audio.currentTime =duration;
  }
 }
}