package com.poz.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.poz.R;
import android.content.*;
import android.app.*;
import android.*;
import android.content.pm.*;
import androidx.core.app.*;
import android.widget.*;
import java.io.*;
import android.webkit.*;
import java.net.*;
import android.net.*;
import android.database.sqlite.*;
import android.database.*;
import android.view.*;
import java.util.*;
import android.os.*;

public class poz extends AppCore{
	Context c;WebView web;ValueCallback<Uri[]> fileValue;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if((keyCode==KeyEvent.KEYCODE_BACK)&&web.canGoBack()){
			web.goBack();
			return true;
		}else{
			if(web.canGoBack()!=true){
				this.finish();
			}
		}
		return super.onKeyDown(keyCode, event);
	}
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		Bundle bundle= getIntent().getExtras();
		String url = bundle.getString("URL");
		web =new WebView(this);
        setContentView(web);
		if(ActivityCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
			ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
		}
		WebSettings setup =  web.getSettings();
		web.setVerticalScrollBarEnabled(false);
		web.setHorizontalScrollBarEnabled(false);
		setup.setJavaScriptEnabled(true);
		setup.setLoadsImagesAutomatically(true);
		setup.setJavaScriptCanOpenWindowsAutomatically(true);
		setup.setDomStorageEnabled(true);
		setup.setLightTouchEnabled(true);
		setup.setSaveFormData(true);
		setup.setAppCacheEnabled(true);
		setup.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
		setup.setLoadWithOverviewMode(true);
		setup.setMediaPlaybackRequiresUserGesture(true);
		setup.setUseWideViewPort(true);
		setup.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		web.addJavascriptInterface(this,"system");
		web.setWebChromeClient(new chrome());
		web.loadUrl(url);
		web.setWebViewClient(new WebViewClient(){
				public boolean shouldOverrideUrlLoading(WebView w,String nextpage){
					web.loadUrl(nextpage);
					return true;
				};
		    	@Override
				public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
				{
					view.loadUrl("file:///android_asset/error.html#"+failingUrl);
					super.onReceivedError(view, errorCode, description, failingUrl);
				}
			});

	}
}