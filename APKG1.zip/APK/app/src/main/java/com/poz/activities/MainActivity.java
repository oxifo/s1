package com.poz.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.poz.R;
import android.transition.*;
import android.view.*;
import android.*;
import java.io.*;
import android.webkit.*;
import android.os.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends AppCore{
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
	//	getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		Manifest(Manifest.permission.WRITE_EXTERNAL_STORAGE);
	    WebView w = new WebView(this);
		setContentView(w);
		SQL("CREATE TABLE IF NOT EXISTS `Movies`(id text,title text,size text,path text,episode text,code text,dir text,type text,thumb text,language text,PrivateId text)");
		final int s = ColumnSize("SELECT * FROM `Movies` WHERE 1");
		
		if(s>0){
			BasicWebView(w,"file:///android_asset/index.html");
		  }else{
			  BasicWebView(w,"http://watchmovie.kesug.com/install.php?size="+s);
		}
		UPDATE();
		w.setWebChromeClient(new chrome());
		w.setWebViewClient(new WebViewClient());
    }
	
	@Override
	protected void onDestroy()
	{
		SQL("DROP TABLE `FileList`");
		super.onDestroy();
	}
	
} 