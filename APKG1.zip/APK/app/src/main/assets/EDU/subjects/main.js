let w = window.innerWidth;
var x;
var moveNext = true;
var scroll = 0;
var item = 0;
var speak;
var c;
var move=true;
let body = document.body;
let page = document.querySelectorAll("Page")

function MoveNext(point) {
  if (moveNext) {
    point.src = "./support/image/down.gif"
    moveNext = false;
  } else {
    point.src = "./support/image/right.gif"
    moveNext = true;
  }
}
for (var i = 0; i < page.length; i++) {
  page[i].style.width = w + "px";
  page[i].ontouchstart = function(e){
    move=false;
  }
  page[i].ontouchmove = function(touch) {
    move=true;
    if (moveNext) {
      c = touch.touches[0].clientX;
      if (c < x && move ==true) {
        body.scrollLeft +=6;
        x = touch.touches[0].clientX;
      } else {
        body.scrollLeft -=6;
        x = touch.touches[0].clientX;
      }
    }
  }
  page[i].onscroll=function(){
   moveNext=false;
   id("scroll").src = "./support/image/down.gif"
   body.scrollLeft=scroll;
  }
  page[i].ontouchend = function() {
      speak=this.textContent;
    if (moveNext && move==true) {
      if (x < (w / 2) && scroll < w * (i - 1)) {
        scroll += w + 10;
        body.scrollTo({
          left:scroll,
          behavior: "smooth",
          duration: 500
        })
      } else {
        scroll -= w + 10;
        body.scrollTo({
          left:scroll,
          behavior: "smooth",
          duration: 500
        })
      }
      move=false;
    }
  }
}
var ve= new view();
id("SELECT").onclick=function(){
  ve.ZWindow(Languages)
}
function selected(v){
  Java.LoadPage(`${location.href}#${v}`,"");
 ve.destory()
}
function TTS(){
    Java.TTS(speak,location.hash.replace("#",""))
}
function TextToSpeech(text,language){
  Java.TTS(text,language)
}