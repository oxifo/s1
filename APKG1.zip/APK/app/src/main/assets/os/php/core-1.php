<?php
  $host="sql205.infinityfree.com";
  $user ="if0_34919471";
  $passwords ="LukLinApp0064";
  $db="if0_34919471_Movies";
  $openDb=mysqli_connect($host,$user,$passwords,$db);
  $encoding =["a"=>2868,"b"=>2134,"c"=>2867,"d"=>1764,"e"=>1168,"f"=>1122,"g"=>1900,
"h"=>1264,"i"=>1054,"j"=>2238,"k"=>3435,"l"=>1988,"m"=>1134,"n"=>1020,"o"=>1111,"p"=>1113,"q"=>1114,"r"=>1224,"s"=>3000,"t"=>3010,"u"=>9999,"v"=>2222,"w"=>3333,"x"=>5454,"y"=>7097,"z"=>4565,"0"=>"9166","1"=>1665,"2"=>2880,"3"=>3111,"4"=>4550,"5"=>5642,"6"=>6833,"7"=>7711,"8"=>8809,"9"=>9023," "=>"0000"
        ];
  function encode($value){
    $v=strtolower($value);
    global $encoding;
      for($i =0;$i<strlen($v);$i++){
       if ($i==0&&$encodeValues!=NULL) {
         $encodeValues=NULL;
       }
       $encodeValues .=$encoding[$v[$i]];
      }
      return $encodeValues;
  }
  function decode($v){
    global $encoding;
    global $runtime;
     $length=strlen($v)/4;
     for ($i = 0; $i <$length; $i++) {
      if ($i==0) {
        $runtime=0;
      }else {
        $runtime+=4;
      }
  echo ReadArray($v,$runtime,$runtime+4);
  
     }
  }
  function ReadArray($V,$S,$E){
    global $decodeValue;
    global $encoding;
      for ($i =$S; $i < $E; $i++) {
        if ($i==$S) {
          $decodeValue=NULL;
        }
        $decodeValue.=$V[$i];
    }
    return array_keys($encoding,$decodeValue)[0];
  };
  function MyFile($url,$act){
      if ($act=="R") {
      $req=fopen($url,"r");
       $fsize=filesize($url);
       if ($fsize>8000000) {
         $read =fread($req,8000000);
       }else{
         $read =fread($req,filesize($url));
       }
        return $read;
      }else {
    $req=fopen($url,"w");
  $write =fwrite($req,$act);
return true;
  }
     fclose($req);
  }
  function IdGenerate($tb){
    global $openDb;
    $select ="SELECT * FROM `$tb` WHERE 1";
    $run =mysqli_query($openDb,$select)->num_rows;
    return $run;
  }
  function zcode($code){
     global $ZV;
     if ($ZV!= NULL) {
       $ZV=NULL;
     }
     global $encoding;
     global $runtime;
     $length=strlen($code)/4;
         for ($i = 0; $i <$length; $i++) {
          if ($i==0) {
            $runtime=0;
          }else {
            $runtime+=4;
          }
        $ZV.=ReadArray($code,$runtime,$runtime+4);
    }
  return $ZV;
  }
  function SQL($query){
    global $openDb;
    $runCode = mysqli_query($openDb,$query);
    if ($runCode->num_rows==1) {
      $data =$runCode->fetch_assoc();
      return $data;
    }
  }
  function value($table,$key,$value){
    global $openDb;
    $query ="SELECT * FROM $table WHERE $key=$value";
    $runCode =mysqli_query($openDb,$query);
    if ($runCode) {
      $data =$runCode->fetch_assoc();
      return $data;
    }else{
      return false;
    }
  }
  function GuessId($table,$key,$v){
     global $userID;global $openDb;
         if ($v==NULL) {
          $query ="SELECT * FROM `$table` WHERE `$key`=$userID";
         }else{
           $query ="SELECT * FROM `$table` WHERE `$key`=$v";
         }
         $proc = mysqli_query($openDb,$query);
         return $proc->num_rows;
   }
  function SQLObject($table,$key,$value){
       global $openDb;
       $query ="SELECT * FROM $table WHERE $key=$value";
       $runCode =mysqli_query($openDb,$query);
       if ($runCode) {
         return $runCode;
       }else{
         return false;
       }
     }
  function CopySQLTable($table){
    global $openDb;
    $query ="SELECT * FROM `$table` WHERE 1";
    $exe =mysqli_query($openDb,$query);
    echo "\$SQLData=array(";
    while($data=$exe->fetch_assoc()){
      $i++;
      $id=$data["id"];
      $title =$data["title"];
      $size =$data["size"];
      $path =$data["path"];
      $episode=$data["episode"];
      $code=$data["code"];
      $dir =$data["dir"];
      $type=$data["type"];
      $thumb =$data["thumb"];
      $language =$data["language"];
      $PrivateId=$data["PrivateId"];
      echo "
      array(
      'id'=>$id,
      'title'=>'$title',
      'size'=>'$size',
      'path'=>'$path',
      'episode'=>'$episode',
      'code'=>'$code',
      'dir'=>'$dir',
      'type'=>'$type',
      'thumb'=>'$thumb',
      'language'=>'$language',
      'PrivateId'=>'$PrivateId'
      ),";
    }
    echo ");";
  }
  ?>