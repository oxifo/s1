var fileno=0;
var x;
var start=null;
var touchend =false;
var created =false;
var zwindow=false;
let wh =window.innerHeight;
let sw = window.innerWidth; //ScreenWidth
function id(v){
  return document.getElementById(v);
}
function byClass(v){
  return document.getElementsByClassName(v);
}
var RequestFileChooserResults;
function placeholder(_id,value){
  id(_id).placeholder=value;
}
function type(_id,value,m){
  id(_id).type=value;
}
class memory{
  mark(k,v){
    return localStorage.setItem(k,v);
  }
  recall(k){
    return localStorage.getItem(k);
  }
  remove(k){
    return localStorage.removeItem(k);
  }
}
function RequestFileChooser(eid,f){
  id(eid).onclick = function(){
    let create=document.createElement('input')
    create.type="file";
    create.click();
    create.onchange = function(){
      var reader = new FileReader();
      reader.onload = function(r){
          id(eid).src=r.target.result;
      }
      reader.readAsDataURL(create.files[0]);
      RequestFileChooserResults=create.files[0];
      f(create.files[0]);
    }
  }
}
function inputValues(eid){
  return id(eid).value;
}
function query(v){
  return document.querySelector(v);
}
function HttpRequest(form,url,open){
  var http =new XMLHttpRequest();
  http.upload.onprogress = function(p){
    console.log(1);
    setRootStyle("--display","block");
  }
  http.upload.onloadend = function(){
    setTimeout(function(){
       var rsp =http.response;
       alert(rsp);
    },3500);
  }
  http.open("POST",url);
  http.send(form);
}
function setRootStyle(name,value){
  let r = document.querySelector(":root");
  r.style.setProperty(name,"\""+value+"\"")
}
function right(e,v){
  e.style.right=v;
}
var ovalue="";
var form =new FormData();
let inp = document.createElement("input");
inp.type ="file";
inp.multiple="true";
class MFile{
  read(fname,callback){
    form.set("name",fname);
    form.set("req", "read");
    fetch("./zfun.php", {
        method: "POST",
        body: form
      }).then(x => x.text())
      .then(v =>callback(v));
  }
  write(fname,content,callback){
    form.set("content",content);
    form.set("name",fname);
    form.set("req","write");
    fetch("./zfun.php",{
      method:"POST",
      body:form
    }).then(x=>x.text())
    .then(v=>callback(v));
  }
  Override(fname,content,index,callback){
    this.read(fname,function(v){
      for (var i = 0; i <v.length; i++) {
        if (i==index) {
          ovalue+=content+v[i];
        }else{
          ovalue+=v[i];
        }
      }
    });
    setTimeout(function(){
      if (ovalue.length > 0) {
         f(ovalue);
      } else {
      return false;
      }
    },1000);
  }
  deleted(fname,callback){
    form.set("req","delete");
    form.set("name",fname);
    fetch("./zfun.php",{
      method:"POST",
      body:form
    }).then(x=>x.text())
    .then(x=>callback(x));
  }
  select(f,form){
    inp.click();
    inp.onchange = function(){
      
      var select =inp.files;
      for (var i = 0; i <select.length; i++) {
      ReadMulti(select[i],form).then(x=>f(x,i));
      }
    }
  }
}
function ReadMulti(file,form){
  return new Promise(done=>{
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function(data){
      fileno+=1;
      done(data.target.result);
      form.set("fNO"+fileno,file);
    }
  });
}
class notification{
  classic(msg,duration){
    var nbody =document.createElement("noti");
    nbody.className="classic_body";
    nbody.innerHTML=msg;
    document.body.appendChild(nbody);
    setTimeout(function(){
      document.body.removeChild(nbody);
    },duration);
  }
 drawer(min,max,content){
  if (created) {
    e.innerHTML=content;
  } else {
     var e = document.createElement("drawer");
     e.style.minHeight = `${min}px`;
     e.style.maxHeight = `${max}px`;
     e.innerHTML = content;
     document.body.appendChild(e);
  }
 }
}
class ZTools{

  subpage(url){
    var x;
    let m = new memory();
    let page =document.createElement("subpage");
    page.innerHTML="loading....."
    fetch(url)
     .then(x=>x.text())
      .then(v=>page.innerHTML=v);
    page.className ="subpage";
    document.body.appendChild(page);
    setTimeout(x=>right(page,"0px"),10);
    page.ontouchmove = function(e){
      x = e.touches[0].clientX;
      this.style.right="-"+(x+150)+"px";
    }
    page.ontouchend = function(){
      if (x > (sw-70)) {
        page.style.right = "-90%";
      } else {
        page.style.right = "0%";
      }
    }
  }
  drawer(view) {
    var x;
    let m = new memory();
    let page = document.createElement("subpage");
    page.innerHTML = view;
    page.className = "subpage";
    document.body.appendChild(page);
    setTimeout(x => right(page, "0px"), 10);
    page.ontouchmove = function(e) {
      x = e.touches[0].clientX;
      this.style.right = "-" + (x + 150) + "px";
    }
    page.ontouchend = function() {
      if (x > (sw - 70)) {
        page.style.right = "-90%";
      } else {
        page.style.right = "0%";
      }
    }
  }
}
var call=false;
function LongTouch(point,f){
    touchend=false;
    setTimeout(function(){
      if (touchend==false){
        f(point);
      }
    },1900);
    point.ontouchend = function(){
      touchend=true;
    }
    
}
function LongTouchText(target){
    var now =Date.now();
    start=now;
  id(target).ontouchend = function(){
    var height = this.offsetHeight;
   if (start == null) {
     system.toast("Try Again")
   } else {
     if ((start + 500) > Date.now()) {} else {
       if (height>250) {
         this.style.minHeight="200px";
         this.style.overflow="hidden"
       }else{
         this.style.minHeight="650px";
         this.style.overflow="scroll"
       }
       start = null;
     }
   }
  }
}false
class view{
  ZWindow(fill){
      var zview =document.createElement("ZWindow");
      zview.innerHTML=fill;
      zview.style.display="block";
      zview.className="zview";
      document.body.appendChild(zview);
  }
  destory(){
    let ze =document.getElementsByClassName("zview")
    for(var e=0;e<ze.length;e++){
      ze[e].style.display="none"
    }
  }
}
const Languages =`<item onclick="selected('ko')"><img width="48" height="48" src="https://img.icons8.com/fluency/48/south-korea-circular.png" alt="south-korea-circular" />
<name>Konea</name>
</item>
<item onclick="selected('ja')"><img width="48" height="48" src="https://img.icons8.com/color/48/japan-circular.png" alt="japan-circular" />
  <name>Japan</name>
</item>
<item onclick="selected('en')"><img width="48" height="48" src="https://img.icons8.com/color/48/great-britain-circular.png" alt="great-britain-circular" />
  <name>English</name>
</item>
<item onclick="selected('my')"><img width="48" height="48" src="https://img.icons8.com/color/48/myanmar.png" alt="myanmar" />
  <name>Burmese</name>
</item>
<item onclick="selected('th')"><img width="48" height="48" src="https://img.icons8.com/color/48/thailand.png" alt="thailand" />
  <name>Thailand</name>
</item>
<item onclick="selected('vi')"><img width="48" height="48" src="https://img.icons8.com/color/48/vietnam-circular.png" alt="vietnam-circular" />
  <name>Vietnam</name>
</item>
<item onclick="selected('zh-CN')"><img width="48" height="48" src="https://img.icons8.com/color/48/china-circular.png" alt="china-circular" />
  <name>China</name>
</item>
<item onclick="selected('hi')"><img width="48" height="48" src="https://img.icons8.com/color/48/india-circular.png" alt="india-circular" />
  <name>India</name>
</item>
<item onclick="selected('lo')"><img width="48" height="48" src="https://img.icons8.com/color/48/laos-circular.png" alt="laos-circular" />
  <name>Laos</name>
</item>
<item onclick="selected('ms')">
  <img width="48" height="48" src="https://img.icons8.com/color/48/malaysia.png" alt="malaysia" />
  <name>Malaysia</name>
</item>`;
document.body.onscroll=function(){
  touchend=true;
}
function SQL(type,code,value){
 return Java.READ("SELECT * FROM `Movies` WHERE `type`='"+type+"' AND `PrivateId`='"+value+"'",code);
}